# Reelix headphone ad — production record

This accompanies the Reelix Explainer lesson. It contains the selected reference sheets and the exact saved generation prompts when retained. Two office prompts are marked as rebuild briefs because the submitted wording was not archived. Source image references in prompts must be replaced with your own approved attachments.

## How to use it

1. Review the creative reference for camera, pacing, texture and humor. Credit the source.
2. Define what changes in your story, cast, product and setting.
3. Lock character, location and prop references before storyboards.
4. Approve the shot list before frames; build start/end anchors only when they teach motion or a camera join.
5. Generate 4–7 second clips; inspect at two frames per second, keep accepted clips and repair only failing beats.
6. Lock picture before music, voice, SFX, grain and export.

## Production defaults

- Still images: Higgsfield Nano Banana 2.1, 2K. 16:9 for sheets and location masters; 9:16 for the vertical film storyboard.
- Moving film: Seedance 2.5, 480p, short 4–7 second generations, no model-generated background music by default. Seedance 2.0 is the specified backup. Some approved footage was made with Katana and retained as a distinct experiment.
- Voice: Danney Enhanced Eleven v4 for the long-form narration. Music was selected and fitted after picture; the headphone action determines the switch.
- Finish: local edit, natural film grain, physical SFX and Reelix end treatment.

## Asset sheets and local prompts

## People

### Danney · Egyptian actor

Image: `assets/character.jpg`
Source: Approved royal character sheet V2
Purpose: The original Danney face controlled identity; the historical reel controlled costume only.
Used: Egypt scenes and later motion anchors.
Accepted limit: The chosen sheet has a documented same-facing profile exception.

Saved generation prompt:

```text
PURPOSE: One photorealistic 16:9 film character reference sheet of Danney dressed as the royal Egyptian character in reference image 2. Exactly three equal panels in a single horizontal row with thin dividers.
REFERENCE MAP:
IMAGE 1 is Danney's ORIGINAL face grid and the sole facial identity authority. Preserve the exact person's face shape, natural eyes/eyelids/eye spacing, brows, nose, lips, jawline, skin tone and age. Original face overrides the source actor's face.
IMAGE 2 is an ACTUAL selected DNA frame at 6.0 seconds. Copy its WARDROBE only: striped Egyptian headcloth, broad gold collar, white draped linen/pleated wrap garment and restrained gold accents. Ignore its actor's identity, chariot, reins, cup, horses, pose and background. Do not recreate this frame's scene or import a second person.
SUBJECT AND WARDROBE: Same Danney in all three panels, natural lean adult build, calm deadpan closed-mouth expression, naturally open eyes, realistic skin pores and tonal variation. Dark-and-light striped nemes-style cloth over crown and draping down either side of neck/upper shoulders, worn gold trim; entire face unobscured. Broad gold collar as in DNA, white draped linen at shoulders and a pleated white linen wrap kilt to around knee level, understated matching gold accents on upper arms/waist. Plain brown leather strap sandals. Tactile woven cloth, natural folds and lightly worn metal like a real photographed costume. Keep wrists accessible for later watch and prop handling. No extra fantasy armour, mask or giant crown. Hands empty. Exactly same face/headgear/collar/linen/gold accents/sandals across panels.
COMPOSITION:
LEFT: FRONT CLOSE-UP. Head and shoulders, face directly toward camera, full headcloth silhouette and head visible with margin. Eyes exactly as original identity reference, natural open lids, no broad laughing grin.
CENTRE: LEFT-FACING MEDIUM. Whole head down to upper thighs. Standing upright. Head, chest, shoulders and hips rotate about 40 degrees toward the IMAGE'S OUTER LEFT EDGE. Nose points LEFT; right cheek visible; right shoulder nearer camera. Gaze left, full headcloth visible.
RIGHT: RIGHT-FACING FULL BODY. Entire head down through both sandal soles and margin below feet. Head, chest, shoulders, hips and feet rotate about 40 degrees toward the IMAGE'S OUTER RIGHT EDGE. Nose points RIGHT; left cheek visible; left shoulder nearer camera. Gaze right. Middle and right views physically face OPPOSITE directions, away from the shared divider. Never repeat their orientation or mechanically mirror facial asymmetries.
ENVIRONMENT: Neutral mid-grey seamless studio across all panels, broad soft even neutral light, gentle grounded shadows. Grey background follows approved sheet layout rather than reference image 2's location.
LOOK: Realistic clean photography and natural undistorted anatomy; no beauty smoothing, plastic skin or illustration. Preserve costume texture from DNA but keep neutral identity-sheet white balance; scenes receive warm dusty grain later.
TEXT: No text, labels, logos or watermark.
ACCEPTANCE: Original Danney face and eyes recognizable; actual DNA costume retained; three equal panels; front close-up/LEFT medium/RIGHT full body; complete heads and feet; opposing head AND torso views; consistent costume; hands empty. No longboard or oversized props in this identity sheet.
```

### Danney · studio presenter

Image: `assets/office-character.jpg`
Source: Office presenter V2, owner-selected
Purpose: A second, approved character sheet keeps the same face while changing hair/clothing for the explainer. Fashion-pin faces were blurred and never used for identity.
Used: Six office appearances in the long-form video.
Accepted limit: The right panel became a rear angle; Danney chose it as an exception.

Rebuild brief · exact submitted prompt was not retained:

```text
Three-panel 16:9 photorealistic presenter sheet. Use Danney’s original face grid as the sole facial identity source. Use the redacted fashion board for short dark hair and a loose white overshirt over a cream shirt, beige trousers, and natural shoes. Close face, opposite-direction medium, and full-body views on a neutral grey background with consistent proportions, natural skin, no labels.
```

### Café barista

Image: `assets/barista.jpg`
Source: Approved barista reference sheet
Purpose: One recurring adult worker makes the café feel inhabited rather than using an unrelated face in each shot.
Used: Café handoff.
Accepted limit: The generated medium/full views face the same way; use for face and outfit.

Saved generation prompt:

```text
Photorealistic THREE-PANEL character sheet: one fictional attractive ADULT woman approximately28, warm olive skin, darkbrown eyes, longdarkbrown hair tiedinlowbun with fewnatural loose strands, same distinctive face/hair/outfit/body in allpanels, calmcompetent friendlyclosed-mouth expression, naturalpores noairbrush. Sleeveless plainoff-white wovenlinen ankle-lengthdress withmodestneckline andsimple brownwaistcord, brownleathersandals, emptyhands, no jewelry/royalheadgear/logos/VOLT. Seamlessneutralmidgrey studio softneutral light.
LEFT frontheadandshoulderscloseup, completehead/hair. CENTRE mediumheadtoupperthighs facingIMAGELEFT, nosepointstowardleftcanvasedge. RIGHT fullbodyheadtosandals facingIMAGERIGHT, nosepointstowardrightcanvasedge andshoulders/hips follow, genuinelyoppositecentre. Allheadsinframe/fullbodysandalsinframe, equalhorizontalpanels/thindividers. Sourceimage1 actualDNAkitchen controls linenmaterial/era only, createNEWfictionaladultface, do notcopysourcecast. Image2courtyardcontrols worldcompatibilityonly, no scene background.
```

### Palace herald

Image: `assets/herald.jpg`
Source: Owner-selected herald sheet
Purpose: A consistent supporting character grounds the final throne joke in the same Egyptian world.
Used: Audience-hall payoff.
Accepted limit: Opposite-angle layout exception accepted.

Saved generation prompt:

```text
LOCALIZED CHARACTER SHEET CORRECTION: image1 original herald reference is exactidentity/outfitauthority. PreserveLEFT frontcloseup andCENTRE left-facingmedium panels completely. Change ONLY RIGHT fullbodypanel.
RIGHT PANEL: The SAME man rotates headANDtorso to face IMAGE RIGHT, about35degree three-quarterturn. His nose points toward RIGHT EDGE ofcanvas; face looks RIGHT, oppositecentre whose nosepointsLEFT. Show his LEFTside nearer camera, notthe same rightside ascentre. Both shoulders/hips/feet rotate naturally right; don't rotate only head. Keep face/hair/age/skin/body/white knee-lengthlinen/brownbelt/brownsandalsidentical. Entireheadandbothfeet visible withmargin atsamefullbodyscale, samegreybackground andlight. Emptyhands. Do not mirrorwholecanvas orleft/centrepanels. No newface, accessories, people, text orlabels. Image2 actualDNA Egyptianclothingmaterialcontextonly, notidentity orlayout. CHECK middlefacesLEFT, fullbodyfacesRIGHT, frontportraitunchanged.
```

### Danney wearing the giant headphones

Image: `assets/worn.jpg`
Source: Approved worn-character V2
Purpose: This intermediate sheet locks the worn scale before the headphone-placement and later scenes.
Used: Temple, market and final ride.
Accepted limit: Face and worn scale accepted; profile order differs from the default layout.

Saved generation prompt:

```text
A photorealistic three-panel film character reference sheet, 16:9, three equally sized panels in one horizontal row with thin divider lines. Neutral mid-grey seamless background, even soft light. Exact same real adult man wearing huge black headphones in every panel. Image 1 ALONE defines face: his actual adult age, exact small natural eyes and eyebrows, nose, lips and lean jaw, clean-shaven, natural pores and tonal variation, calm focused closed-mouth deadpan. Image 2 defines EXACT headphone geometry and printed logo, copy its actual outer-earcup logo shape literally, do not invent or reinterpret it as another generic reel icon. Keep its original black shell and exact VOLT #D4FF3D ink. Image 3 defines Egyptian clothing only: original striped headcloth covering all hair, broad gold collar, white draped linen outfit, gold cuffs and leather sandals, lean normal body. Image 4 supplies authentic Egyptian linen/headcloth materials only. LEFT PANEL: close frontal head-and-shoulders portrait, nose toward camera, whole headband and both whole earcups visible. CENTRE PANEL: waist-up exact LEFT SIDE PROFILE, face and torso facing image-left, nose points toward LEFT edge, right earcup outer face toward camera. RIGHT PANEL: full-body exact RIGHT SIDE PROFILE, face and torso facing image-right, nose points toward RIGHT edge, left earcup outer face toward camera. Opposed body directions are essential. Both headgear and sandals fully visible in right panel. Wear same headset throughout: each round earcup is a 30cm dinner plate, taller than face brow-to-chin, extending temple to gold-collar level; headset wider than shoulders. Preserve identical earcup diameter divided by face height in every view. Empty hands resting at sides. The two side-profile silhouettes face AWAY from each other. No text/labels, no extra objects, no different faces, no mirror-created logo, no duplicated mark elsewhere.
```

## Places

### Royal courtyard

Image: `assets/location.jpg`
Source: Owner-approved courtyard master
Purpose: Single wide three-quarter master establishes the ancient-modern world and the longboard path.
Used: Early arrival and overall geometry.
Accepted limit: Entrance threshold and paving roughness were accepted; stage rolling shots on a clear lane.

Saved generation prompt:

```text
PURPOSE: One single photorealistic LOCATION MASTER image for Danney's ancient Egyptian morning comedy. Landscape16:9, one uninterrupted WIDE SHOT from a THREE-QUARTER CORNER camera position. No collage, grid, split screen, panels or alternate views.
REFERENCE MAP: Reference1 is actual DNA5.5s: weathered Egyptian walls and contemporary service window integrated naturally. Reference2 is DNA7.5s: ancient kitchen materials and practical warm sunlight/shadow. Reference3 is DNA9.0s: sandy market architecture, fabric awnings and everyday modern commerce. Copy their photographic texture, materials, light and historical-modern coexistence. Ignore source people, horses, chariot, food action and exact original composition.
LOCATION: A royal Egyptian sandstone courtyard opening directly onto an ancient-modern market street, with its cafe/kitchen in the rear wall. About60percent ancient and40percent modern in FEEL: Egyptian columns, two weathered royal statues, carved aged stone and plaster, timber lintels, linen awnings, clay vessels and a monumental sundial mixed with visibly functional modern retail infrastructure. An OPEN stainless cafe service hatch with counter, dark glass shop opening, plain blank menu/display panel, exposed utility conduit and a modern faucet in the stone washbasin. Make these modern features readable rather than tiny decoration. No futuristic city or pristine shopping mall. Warm sandy world, ordinary modern conveniences.
MASTER CAMERA: Camera at human eye height in the SOUTH-EAST street/entrance corner, looking diagonally NORTH-WEST into the courtyard. About24mm photographic perspective with natural architecture and no fisheye. Show foreground street and a clear diagonal longboard route through south gateway, both adjacent wall planes and enough courtyard floor to establish scale. Same image includes royal columns/statues framing entry, north cafe doorway and service counter at rear, east stone washbasin on nearer/right side, west monumental sundial farther/left. Kitchen implied through open doorway/hatch; do not invent a separate interior viewpoint in this image.
GROUND AND GEOGRAPHY: Courtyard about14mwide by10mdeep; market street EAST-WEST immediately SOUTH. NORTH wall: doorway WEST of service hatch, connected cafe/kitchen behind. EAST basin, WEST sundial and stone ledge. Statues flank SOUTH gate. Entry street and courtyard floor are continuous and LEVEL: no entry steps, stair, raised sill or obstructing curb across the longboard path. Weathered paving/dust retains authentic texture. Preserve usable open rolling space; no hero props yet.
LIGHT AND LOOK: Actual DNA's warm dusty sunlight, sandy ochre/cream/earth colours, slightly muted contrast, candid grainy photographed film feel, imperfect worn surfaces. Consistent morning sun fromSOUTHEAST, naturally shaded recesses. Avoid glossyHDR, oversharpenedCGI or sterile resort lighting.
TEXT: No words, labels, brand names or watermark; any modern menu/display panel stays blank.
ACCEPTANCE: ONE SINGLE wide3/4corner view; royalcourtyard+marketstreet clearlyconnected; readable ancient-modernmix; level longboardroute; nocharacters/animals/vehicles/longboard/toothbrush/espresso machine/watch. Once THIS master is approved, other camera perspectives may be generated from it only for locations reused in2+approvedshots.
```

### Construction courtyard and crane

Image: `assets/construction.jpg`
Source: Owner-approved construction master
Purpose: A crane and suspended obelisk give the camera a physical reason to travel down toward the rider.
Used: Crane-to-longboard passage.

Saved generation prompt:

```text
LOCATION MASTER: ONE photorealistic wide 3/4 corner view, 16:9, of a royal ancient Egyptian construction courtyard. Image 1 is the ACTUAL ORIGINAL DNA opening: borrow immense ancient stone scale, modern working crane contrast, sandy worn materials, dusty sunlight, fine photographic grain, soft subdued contrast and ordinary construction activity. Image 2 supplies compatibility with our royal columns, statues and courtyard architectural world only. Create a distinct coherent location rather than copy image1 composition. Ancient carved sandstone columns, unfinished temple wall and royal statue plinths occupy about60percent of world design; modern yellow/steel construction crane and understated scaffolding integrated as working equipment. Show complete readable crane tower and jib in sky, cable and spreader rig supporting ONE sandstone obelisk vertically above its empty socket. Load hangs a little above ground, not floating without cables. Crane hoist and obelisk separated visually from foreground. At least4small ordinary adult linen-clad workers perform rope-guiding/stonework across site, natural unstaged poses, no hero. Broad level hard-packed sandy/stone foreground route clear for longboard arrival, away from suspended load. Establish visible near-corner-to-open-courtyard-to-crane depth so a later camera can descend/approach through that corridor. Single wide corner perspective only; no grid, no multiple frames, no superimposed motion arrows, no logo/green accents/OPEN sign. Real lived-in historical construction mixed with modern crane, matching reference softgrain rather than CGI/game render.
```

### Palace washroom

Image: `assets/washroom.jpg`
Source: Owner-reviewed location master
Purpose: Separate location reset for the giant toothbrush gag, with daily activity behind Danney.
Used: Brushing scene.

Saved generation prompt:

```text
ONE WIDE THREE-QUARTER CORNER LOCATION MASTER,16:9 singleimage,nogrid,nopeople. RoyalEgyptianPALACEWASHROOM distinctfromopen courtyard: enclosedwornsandstonechamber, deepcarvedstonewashbasinonleftwall, practicalmodernsteel tap discreetlyintegrated, highsmallwindow castingsoftdustyshaft, foldedoffwhitelinen onwoodenstool/alcove, smallterracottawaterjar. Enoughclearfloor/standingzonebesidebasin forDanneywithheadgear-heighttoothbrush later; nohero brushyet. No coffeemachine/cafédoor/marketstalls. Bareminimumconduit/faucet supportsancientmodernfeel butancientmaterialdominant. Sourceimage1actualDNAgroomingroom controls dustyoldstone/intimateroomfeeling; don'tcopyhairdryer/mummy/cast/action. Image2royalcourtyarddefinesrelatedsandstonecraftsmanship only, NOTsamecourtyardlayout. Softgrain/mutedwarmcontrast,naturalwear, observationalwidehumaneyeheightstraightverticals. No text/logos/neon/VOLT.
```

### Café and kitchen

Image: `assets/cafe.jpg`
Source: Selected neutral café master
Purpose: The service counter gives the barista and huge machine clear staging, while the tiny cup lands the joke.
Used: Espresso handoff.

Saved generation prompt:

```text
SCOPED CORRECTION of kitchen master image1. Preservekitchen3/4cornercamera,columns/hearth/jars/counter/floor,doorLEFT/hatchRIGHT,dustylightandscenegeometry.
MACHINE: Match exactselectedORIGINALNEUTRALtallV1machine image2: upperhousingBRUSHEDSTEELfront and MATTEBLACKside, lowercabinetSTEEL, blackcontrols/portafilter, tinyWHITEcup samepositionandsize. Removeexistinggreenfascia entirely. NoVOLTpaint anywhereinkitchen, no brandlogo.
EXTERIORVIEWCORRECTION: Image3 authoritativecourtyardexterior hasONEcafé onthewallweareINSIDE. ThroughkitchenRIGHTservicehatch andLEFTdoor see theCOURTYARDOPPOSITESIDE: sandstonepaving, oppositeancientstonecolumns/wall andgateway/marketcontextasviewallows. Remove thecurrentduplicatedcaféhatchanddarkdoor façade seenacrosscourtyardthroughwindow. No secondcafé,no secondOPENsign. Do not moveinterioropenings. ExistingneonOPEN onOUTSIDEaboveourhatch isnotvisiblefrominsideandnotduplicatedindoors. Keepnaturalbrightdaylightoutside/dimsoftinteriortransition.
Image4 actualDNAkitchen7.5s dust/wear/graincontextonly, no microwave/castcopy. Noaddedobjectsorpeople. CHECK exactneutralmachineandtinycup, no green, no duplicatecafefrontoutsidewindow, originalroom/camera retained.
```

### Market lane

Image: `assets/market.jpg`
Source: Owner-reviewed market master
Purpose: A connected lane supports movement and the receipt beat instead of feeling like a disconnected backdrop.
Used: Post-headphone market passage.

Saved generation prompt:

```text
ONE WIDE THREE-QUARTER CORNER LOCATION MASTER,16:9 singleimage,nogrid,nopeople. Bustling-market-ready ANCIENT EGYPTIAN MARKET LANE distinctfromroyalcourtyard: irregularsandstonebuildings, linenawnings, breadsellerstable withloaves/wickerbaskets, smallclayjars/fruitstall, widepedestrianroute passingcounter. Tablehasclearworkingarea forcompactreceiptprinter plusspaceonfloor for2munspooledpaperstrip inlaterstoryboard; no printeryet. No coffeemachine/servicewindow/OPENsign orroyalthrone. Smallmundaneelectricaloutlet discreetlybeneathcounter supplies40%modernfunctioncontext withouttransformingintomodernshoppingmall. Sourceimage1actualDNAmarket controls sunnydustyworking-streetdepth/marketmaterials; donotcopycast,mummy/coffin/paymentjoke. Image2selectedcourtyardancientworldcompatibility only, notsamegeometry. Wide3/4corner angleincludeswalkroute/counter/roomforbackgroundworkers later. Naturalwear,mutedstone/linen,sourcegrain, no CGpolish, no logos/green/text.
```

### Temple entrance

Image: `assets/temple.jpg`
Source: Owner-reviewed temple master
Purpose: The headset pickup gets its own architectural stage and natural light direction.
Used: Headphone pickup and placement.

Saved generation prompt:

```text
ONE WIDE THREE-QUARTER CORNER LOCATION MASTER,16:9 singleimage,nogrid,nopeople. RoyalEgyptianTEMPLEENTRANCE: monumentalpairedsandstonepylons andcolumnedportico, broadshallowsteps andclearflatforecourt forheraldtointerceptpharaoh, worncarvedstone andplainlinenawning, smallstoneledge atforecourt for tinycup/headphones beforewearing. Distinct fromcourtyardcafé andmarket; no caféhatch/OPENsign/basin/hero props. Entrydarkdoorway leadsintoaudiencehall; morningdustydaylight, neutralstone/brownlinencolors. Sourceimage1actualDNAroyalEgyptianframe definesera andsunlight/textures ONLY, no cast/chariotcopy. Image2approvedroyalcourtyard compatible architecturalfamily only, notduplicatedlayout. Widehumaneyeheight3/4corner observationalview, roomforordinarytempleworkerslater, naturalgrain/mutedcontrast. No logos/VOLT/moderndecorativeglow or readablewriting.
```

### Audience hall

Image: `assets/hall.jpg`
Source: Owner-reviewed audience-hall master
Purpose: The throne and herald payoff need a room with readable depth and physical space around the chair.
Used: Final palace gag.

Saved generation prompt:

```text
ONE WIDE THREE-QUARTER CORNER LOCATION MASTER,16:9 singleimage,nogrid,nopeople. RoyalEgyptianTEMPLEAUDIENCEHALL: interiorwornsandstonepillaredhall, one modeststone-andwoodthronewithrestrainedagedgoldtrim atfarend onlowdais, clearcentralaisle, lowstonebenches/offwhitelinen nearwalls forofficialslater. Maincharacterwill sitandholdtinyespresso wearinggiantheadphones; generousclearspacebesidethrone forheraldgesture, avoidpropsblockingfaces. Templefamily massivecolumncarving/stone similarimage2, distinctfromkitchenwithno hearth/machine/counter/caféwindow. Dustysoftshaftsfromhighclerestory, warmdiminteriorwithreadablefaceslater, tangibleagedstone/linen andmutedgrain, no spectacleblue/goldglow. Image1actualDNAkitchen providesobservationaldustyinteriorlighting/naturalworking-worldtexture only, NOTkitchenlayout/people/appliance. Image2royalcourtyard suppliesera/architecturalfamily notsamegeometry. Wide3/4corner establishes throne/aisle/officialspace, no extra modernhero props, logos,green,text.
```

### Danney’s studio

Image: `assets/office-master.jpg`
Source: Owner-approved office master V1
Purpose: The explainer uses one connected office: walnut slats, concrete storyboard wall, desk, windows, real monitors and working clutter. Camera angles rotate within this space.
Used: Presenter interludes.

Rebuild brief · exact submitted prompt was not retained:

```text
One wide 16:9 three-quarter office master. Combine the owner’s Studio/office references by role: concrete/window/lounge architecture, working editing desk, walnut slats and warm practical light. Preserve a connected room with a clear central standing zone, dual monitors, notebook, cables, plant and empty wall for local overlays. Natural daylight, believable materials and subtle grain; no floating UI or generic text.
```

## Props

### Giant Reelix headphones

Image: `assets/headphones.jpg`
Source: Owner-selected headset sheet
Purpose: Only this object carries the canonical Reelix mark; scale is checked against the hand and head in separate shots.
Used: Campaign hero object.

Saved generation prompt:

```text
LOCALIZED BRAND COLOR CORRECTION of image1 only. Preserve the same matteblack oversized overear headphones, exact geometry, materials, hinges, cushioning, panel layout, camera views, studio lighting and grey background. Change ONLY the Reelix marks already printed on BOTH OUTER EARCUPS. Replace their white ink with the authentic REELIX STUDIO VOLT GREEN, exact source color #D4FF3D, RGB21225561, from image2. Preserve exact Reelix mark geometry: outer film-reel circle, four satellite holes, centralcircle and right-pointing play triangle. Every visible logo in allthreepanels uses the same VOLT green. Authentic flat printed pigment: no white logo, no gold, no teal, no neon emission, no coloredlightcast. Keep normal material-light shading but maintain sourcebrandhue, not scenegrade recoloring. Both physical earcups carry the same correctly oriented mark, not mirrored. No text added, no new brandingelsewhere, no headphone/body/background recoloring. Image2 is authoritative originalLogo raster from canonicalSVG colored with Studio theme exact --volt token. Image3 actualDNA appliance frame is context-only to retain mundane contemporaryproduct material; ignore its people, shape and room. CHECK: originalheadphone design and layout retained, VOLTmarks onopposingearcups, no white branding, recognizablelogo geometry.
```

### Longboard

Image: `assets/board.jpg`
Source: Owner-approved neutral board
Purpose: The deck, trucks and wheels stay the same across riding shots; feet must remain planted on the board.
Used: Arrival and crane ride.

Saved generation prompt:

```text
PURPOSE: A photorealistic three-panel PROP reference sheet for Danney's modern LONGBOARD used inside the ancient Egyptian comedy. Landscape16:9, three equal horizontal panels separated by thin lines, mid-grey seamless studio, no labels.
REFERENCE MAP: Image1 is actual DNA5.0s showing a horse-drawn chariot at an ancient service window. Use the concept of ordinary transportation in a historical-modern world, grounded wheel/contact geometry and tangible materials. The source contains NO longboard: do not copy horses, chariotshape, gold ornament, people or original layout. Image2 is approvedlocationmaster, informing warm-world material compatibility and route context only; keep the output studio neutral. This newly chosen modern longboard replaces transportation for our original gag, not a historical-looking chariot skateboard.
PROP DESIGN: ONE regular adult-sized modern cruiser longboard approximately1.1m long and25cm wide, directional pintail/teardrop silhouette: rounded broad nose, narrower gently pointed tail, slight deck concavity, flat usable standing area. Black textured grip tape on top, natural maple wood edges and underside with visible laminated plies, simple black metal trucks, FOUR soft muted orange urethane wheels around70mm diameter. No motor, lights, giant size, Egyptian pattern, logos or words. Realistic recognizable longboard, simple plain design, physically plausible trucks/axles and wheel clearance. Same exact board in all panels.
COMPOSITION:
LEFT: front CLOSE-UP detail of nose section and front truck/wheels, griptexture/woodedge/axles readable, complete visiblewheelbounds.
CENTRE: MEDIUM three-quarter view toward imageLEFT, closer crop of topdeck/front two-thirds, showing grip and one truck assembly; directional nose points left.
RIGHT: FULL complete board with nose pointing imageRIGHT, opposite the middle view. Three-quarter angle shows other side, deck and both truck assemblies/allfour wheels sufficiently readable. Entire nose/tail/wheel boundaries included with margin. Board resting naturally on its wheels on same studio ground plane, not floating. Maintain directional shape rather than making a symmetric different skateboard.
LIGHT AND LOOK: broad soft even neutral studio light, subtle grounded wheel shadows, realistic rubber/metal/wood/grip detail. Clean photographed object, not illustration or glossy3Drender. DNA dusty lighting belongs to scenes later.
TEXT: none, no label/logo/watermark/ruler.
ACCEPTANCE: three equalpanels, detail/medium/fullobject, opposite directionalnose orientation, same board materials/dimensions/truck geometry, four wheels, complete objectbounds, no people/hands/room/scenery/other props.
```

### Person-height toothbrush

Image: `assets/brush.jpg`
Source: Selected brush prop
Purpose: Its scale makes the morning routine funny; a tiny green accent replaces an overpowering full-VOLT finish.
Used: Washroom brush beat.

Saved generation prompt:

```text
LOCALIZED FINAL PALETTE EDIT of approved originalelectrictoothbrush image1. Keep its exact MATTE BLACK handlebody, silvercollar, WHITEbrushhead/bristles, proportions/mechanics, grey studio,3panellayout/framing/light. Change ONLY smallpowerbutton: darkblue/black button centre withONEthinpaintedVOLTGREEN#D4FF3D ring aroundbuttonedge. This tinybuttonrim is the onlygreenonthewholebrush. No greenhandleband, greenbody, greenbristles, lightgloworlogos. Removechargingdock/stand ifpresent, leavingbrushbasegroundedlikeapprovedscene; nootherobjectchanges. Image2 exactVOLTswatch hueauthorityonly; image3actualDNA3s mundane modernappliance materialscontextnotcast/shape/room. Preservebrushbodydimensions, usefullobjectpanelasbodyauthority for laterheadgearheightscale. Exactlysamebuttonrim/materialplacement acrossviews. No logos orletters. CHECK mostlyblack/white/silver brush, tinyVOLTrim only, no dock, no newgeometry.
```

### Huge espresso machine and tiny cup

Image: `assets/espresso.jpg`
Source: Owner-kept V1 silhouette, smaller-cup revision
Purpose: The machine/cup mismatch is the joke, so the cup size is a separate acceptance check.
Used: Café beat.
Accepted limit: Cup reduction is visible but smaller than the originally requested one-third target.

Saved generation prompt:

```text
Edit image1 only: preserve the ORIGINAL V1 tall stainless-steel and matte-black espresso machine, all its geometry, controls, portafilter, tray, material, lighting, three-panel composition, camera viewpoints and grey studio background exactly. Change ONLY the existing white espresso cup in each panel. Reduce each cup to approximately ONE THIRD of its current height and width, preserving its plain white ceramic design and single loop handle. Keep one cup per panel at the same location on the tray beneath the outlet, resting physically on the tray. The full machine is approximately2m tall; the cup represents a tiny normal espresso serving and should look comically miniature next to the machine. Left close-up still shows the cup clearly but it is much smaller than before. Preserve machine size; do not shrink machine with cup. No added people, saucers, labels, extra cups or redesigned horizontal coffee machine. Image2 is actual DNA kitchen frame: reference for original historical-modern appliance comedy context only; do not copy its people, microwave or layout. This is a localized cup-size edit, not a redesign.
```

### Papyrus receipt printer

Image: `assets/printer.jpg`
Source: Owner-reviewed prop sheet
Purpose: Connects a familiar modern checkout behavior to the market setting.
Used: Receipt beat.

Saved generation prompt:

```text
Photorealistic THREE-PANEL prop reference sheet, one ordinary compact modernthermalreceiptprinter, mattecharcoalblack plastic, simplesmallblackbutton, realisticpaperoutlet, no logos/letters/green. Itsjokeis a ridiculously LONG2mreceipt:80mmwide warmivorythinpaperwithsubtlepapyrus-likefibertexture, mechanicallyflexible ordinaryprinterpaperNOTactualthickpapyrus. No readableprintedtext. Onecontinuousstrip emergesfromoutlet andlooselyunrollsonfloor; sameprinter/stripwidthandmaterials inallviews. Leftclosefrontoutletdetail/paperfiber, centremediumleftfrontquarter, rightFULLoppositerightfrontquartershowsprinterandentireunspooledreceiptwithmargin, notcutoff. Greyneutralstudio softlight/thindividers16:9threeequalpanels. Sourceimage1actualDNAmarket digitalpaymentframe supplies mundane contemporaryretailmaterials only: doNOTcopypaymentterminalshape/merchant/mummy. Image2ancientcourtyardworldcompatibility only. Printedpaperandmachineordinarymanufactured, no fantasygoldornament.
```

### Swivel-base throne

Image: `assets/throne.jpg`
Source: Owner-approved throne reference
Purpose: The modern swivel base turns the palace payoff into a physical action, not just a static visual gag.
Used: Audience-hall payoff.

Saved generation prompt:

```text
PROP REFERENCE SHEET: ONE 16:9 photorealistic image with three equally sized panels in one horizontal row and thin dividers, neutral mid-grey seamless studio and broad soft even lighting. One consistent ROYAL EGYPTIAN SWIVEL THRONE shown at3scales/angles. Image1 supplies approved throne silhouette and golden-brown carved wooden materials from our audience hall; image2 actualDNA supplies ordinary ancient-modern joke compatibility, weathered material and subdued texture only, not copying sarcophagus. Chair is lightweight carved darkwood with restrained aged gold accents, tall Egyptian patterned back, broad armrests and linen seat cushion. A modern matte-black load-bearing metal office-chair central swivel spindle and sturdy five-spoke base with small black castor wheels visibly support the entire wooden throne. No stone steps or stone plinth attached: this chair can physically swivel while seated. Base connects directly under seat, plausible construction with continuous spindle. LEFT close detail of swivel spindle, underside seat support and castor junction. CENTRE entire chair three-quarter view turned toward IMAGE LEFT. RIGHT entire SAME chair three-quarter view turned toward IMAGE RIGHT, opposite centre. Both entire-chair views include top of backrest and all castor wheels on same ground line. Keep size/design/materials identical, worn realwood/steel/lightlinen, practical physical ancient throne on modern officechair mechanism. No occupant, labels, extra props, logos or green accents; no detached wheels floating.
```


## Movement examples

The paired frames show the intended action/camera endpoints. These are saved production prompts, not a requirement to generate two stills for every shot. A new location needs its own anchor; adjacent movement may need a backward extension.

### Brush the teeth · keep real-time action

Start image: `assets/brush-start.jpg`
End image: `assets/brush-end.jpg`
Uses: Egyptian Danney + washroom + giant brush
Why: This corrected take shortened the awkward action and kept the background attendant engaged in ordinary work.

Saved movement prompt:

```text
A brisk four-second candid daily-life shot beginning from the approved start image. Reference character sheet defines the same man's identity and royal outfit. Prop sheet defines the toothbrush design; preserve its accepted start-frame size. Location sheet defines this stone washroom. The man is already using the toothbrush as the shot starts: bristles contact the front teeth, lips parted just enough for normal brushing, hands firmly supporting the handle. During the first two seconds he performs three clearly visible short repeated brushing strokes across the front teeth, with small controlled wrist and forearm movements, never an idle hold or a broad swing. His head is angled down toward the basin, eyes on the task; ordinary unselfconscious morning routine. During the last two seconds he completes brushing and lowers the brush over the basin in one purposeful movement. Keep physical contact coherent, brush rigid and face stable. The attendant is independently occupied throughout: folds one towel, lays it on the stack, picks up the next towel and starts folding it. His eyes stay on towels and hands for the entire shot; no glancing at the man or camera, no startled reaction or staged pose. A short decisive camera move forward and slightly sideways happens early while both tasks continue, with visible background parallax and contextual basin/attendant framing. Normal brisk real-time activity, no slow motion, lingering hold, floaty movement or dramatic pause. Soft dusty daylight and fine natural grain from the accepted frame, unchanged room/cast/wardrobe/brush scale. Silent, no dialogue or music.
```

### Serve the tiny espresso

Start image: `assets/coffee-start.jpg`
End image: `assets/coffee-end.jpg`
Uses: Barista + café + huge machine / tiny cup
Why: The visual payoff depends on showing both machine scale and the much smaller cup.

Saved movement prompt:

```text
Candid daily life, brisk ordinary real-time motion with actions already underway, no slow motion or theatrical pauses. Nobody looks into camera. Preserve identity, approved clothing, prop designs and the start-frame room. Background people stay independently occupied unless the herald's attention request is part of the joke. Soft dusty photographic grain and muted warm materials matching our approved film frames. Silent, no music or dialogue. S03 CAFÉ. Approved start establishes barista left, Danney right and warm-white OPEN sign. Character sheet defines Danney, barista sheet defines the adult barista, appliance sheet defines exact tall steel/black espresso machine and tiny white cup; kitchen/café refs define location. Coffee making is underway: barista operates the lever, a brief visible steam vent and thin espresso stream enter the ONE tiny cup beneath outlet. She picks up that cup and extends it across counter; Danney looks at cup, reaches with anatomical RIGHT hand and accepts it by handle, keeping it level. Single handoff, no duplication. Machine remains huge beside barista, cup remains tiny. Camera tracks a short distance laterally toward the handoff while retaining machine, barista and café context. Rear worker rinses utensil and sets it aside without watching them. OPEN stays warm-white and spelled OPEN, no green appliance or extra logos.
```

### Pick up and wear the headphones

Start image: `assets/headphones-start.jpg`
End image: `assets/headphones-end.jpg`
Uses: Egyptian Danney + worn-headset sheet + temple + logo authority
Why: The accepted prop and worn-character sheet lock the size; the brand mark was corrected in the ending.

Saved movement prompt:

```text
Candid daily life, brisk ordinary real-time motion with actions already underway, no slow motion or theatrical pauses. Nobody looks into camera. Preserve identity, approved clothing, prop designs and the start-frame room. Background people stay independently occupied unless the herald's attention request is part of the joke. Soft dusty photographic grain and muted warm materials matching our approved film frames. Silent, no music or dialogue. S05 TEMPLE. Approved worn-character sheet is Danney identity/outfit and WORN HEADPHONE SCALE authority, prop sheet defines exact headset/materials/authentic Reelix VOLT #D4FF3D marks on both earcups; herald sheet defines second man; temple master defines geometry; espresso reference defines tiny cup only. Start from held headset above head and cup on ledge. First 0–2s: Danney immediately lowers the headset onto headcloth using BOTH hands, earcups stay same physical size during descent, no shrinking, no face clipping; final fit matches approved worn sheet, not normal consumer headset. 2–4s: release headset, lower arms naturally and pick up ONE tiny white cup from ledge with RIGHT hand. 4–7s: he walks one short relaxed step toward temple and takes a small sip after cup reaches lips, eyes on path/cup. Herald makes one restrained open-palm request then checks his own papers; only he requests attention, no crowd reaction. Danney remains calmly occupied, no camera eye contact. Two distant workers carry folded linen through portico. Brief brisk camera side arc during headset placement, retain full headset/hands/ledge and contextual temple. Logos keep exact reference shape and VOLT hue, no floating mark, no extra props or music.
```

### Connect the crane to the ride

Start image: `assets/crane-start.jpg`
End image: `assets/crane-end.jpg`
Uses: Construction master + approved board + riding clip
Why: Use a backward extension into the accepted riding clip only when the camera path and actor state genuinely need one continuous join.

Saved movement prompt:

```text
Extend BACKWARD before the supplied approved3.5-second riding video with a four-second continuous crane-to-rider camera approach. Preserve the approved riding portion for the final edit; generated preceding action must naturally meet its exact first camera position, actor pose, face, board contacts, architecture, crane/load placement, shadows and rolling direction. Location image supplies our established Egyptian construction courtyard geometry/crane/obelisk only. DNA image supplies dusty soft muted real photographic texture only. Begin elevated very wide over the working construction courtyard and huge crane/hoisted obelisk. Brief establishment, then a brisk decisive descending forward camera approach with real depth parallax through the clear lane toward Danney on his board. End at the exact incoming riding-video first-frame viewpoint and state, carrying consistent camera and board momentum, so there is one continuous camera journey. Match source subject and wardrobe exactly, same neutral board/orange wheels. Build the near-scene from supplied video, never shift columns/statues/crane behind Danney at the join. Natural real-time energy, no slow-motion or prolonged settling. Backgroundworkers carry blocks and adjust rigging individually, away from rider lane; hoist visibly lowers obelisk slightly on taut cables, crane tower stays physically rigid. At join actor, deck and machine shapes stay consistent; no morphing, extra feet or camera jump. Silent output, no music/voice/sound. Do not redo riding techniques; generate only the preceding approach.
```
